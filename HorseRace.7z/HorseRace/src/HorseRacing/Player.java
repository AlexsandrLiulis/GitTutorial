package HorseRacing;

public class Player {
    private String playerName;
    private int cash;

    public Player(Helper helper) {
        playerName = helper.setPlayerName();
        cash = 50;
    }

    public String getPlayerName() {
        return playerName;
    }

    public int getCash() {
        return cash;
    }

    public void setCash(int cash) {
        this.cash = cash;
    }
}