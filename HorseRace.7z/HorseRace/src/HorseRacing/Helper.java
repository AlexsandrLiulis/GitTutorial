package HorseRacing;

import java.util.Scanner;

public class Helper {
    private String winner;
    Scanner scanner = new Scanner(System.in);

    public void logicGame(HorseStable horseStable, Player player, Racing racing) throws InterruptedException {
        start(horseStable, player);
        chooseHorseName(horseStable);
        messageStartRase();
        while (player.getCash() > 0) {
            Horse winner = racing.race(horseStable);
            if (winner != null) {
                outcomeGame(winner, player);
                if (messageContiniusGame() != 0) {
                    if (player.getCash() > 0) {
                        horseStable.resetDistance();
                        logicGame(horseStable, player, racing);
                    } else {
                        messagebankrupt();
                        finishGame();
                    }
                } else {
                    finishGame();
                    break;
                }
            }
        }
    }

    public void start(HorseStable horseStable, Player player) {
        System.out.println(player.getPlayerName() + " на Вашем щету " + player.getCash() + " $");
        System.out.println("Размер ставки составляет 10 $ \n");
        System.out.println("В забеге учавствуют следующие лошади:\n");
        horseStable.showStable();
    }

    public void chooseHorseName(HorseStable horseStable) {
        System.out.println("\nВведите кличку лошади, которая по Вашему мнению победит");
        boolean choose = true;
        while (choose) {
            String name = scanner.nextLine();
            if (name.isEmpty() || name.trim().length() == 0) {
                System.out.println("Попробуйте ещё раз");
            } else {
                for (int i = 0; i < 5; i++) {
                    if (name.toLowerCase().equals(horseStable.stable[i].getHorseName().toLowerCase())) {
                        winner = horseStable.stable[i].getHorseName();
                        choose = false;
                        break;
                    }
                }
                if (choose) {
                    System.out.println("У нас нет такой лошади.Попробуйте ещё раз");
                }
            }
        }
    }

    public int continueGame() {
        while (true) {
            String x = scanner.nextLine();
            if (x.equals("0")) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    public void outcomeGame(Horse winner, Player player) {
        System.out.println("Победил " + winner.getHorseName());
        if (winner.getHorseName().toLowerCase().equals(getWinner().toLowerCase())) {
            System.out.println("\nПоздравляем Ваш скакун победил!");
            player.setCash(player.getCash() + 10);
            System.out.println("Ваш баланс составляет " + player.getCash() + " $");
        } else {
            System.out.println("\nУвы Вы проиграли!");
            player.setCash(player.getCash() - 10);
            System.out.println("Ваш баланс составляет " + player.getCash() + " $");
        }
    }

    public void messageStartRase() {
        System.out.println("Скачки начались");
    }

    public int messageContiniusGame() {
        System.out.println("\nПродолжим? Для выхода - 0");
        return continueGame();
    }

    public void messagebankrupt() {
        System.out.println("Увы, вы банкрот");
    }

    public void finishGame() {
        System.out.println("До свидания");
    }

    public String getWinner() {
        return winner;
    }

    public String setPlayerName() {
        System.out.println("Введите имя");
        while (true) {
            String name = scanner.nextLine();
            if (name.isEmpty() || name.trim().length() == 0) {
                System.out.println("Поопробуйте ещё раз");
            } else {
                return name;
            }
        }
    }
}