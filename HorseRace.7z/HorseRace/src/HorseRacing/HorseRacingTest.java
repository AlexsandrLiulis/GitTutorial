package HorseRacing;

public class HorseRacingTest {

    public static void main(String[] args) throws InterruptedException {
        Helper helper = new Helper();
        Player player = new Player(helper);
        HorseStable horseStable = new HorseStable();
        Racing racing = new Racing();
        helper.logicGame(horseStable, player, racing);
    }
}