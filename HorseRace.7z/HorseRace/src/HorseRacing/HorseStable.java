package HorseRacing;

public class HorseStable {
    public Horse[] stable = new Horse[5];

    public HorseStable() {
        stable[0] = new Horse("Арабеск");
        stable[1] = new Horse("Кинг");
        stable[2] = new Horse("Кумир");
        stable[3] = new Horse("Фазан");
        stable[4] = new Horse("Могучий");
    }

    public void showStable() {
        for (int i = 0; i < stable.length; i++) {
            System.out.println(stable[i].getHorseName());
        }
    }

    public void resetDistance() {
        for (int i = 0; i < stable.length; i++) {
            stable[i].setCurrentDistance(0);
        }
    }
}