package HorseRacing;

public class Racing {
    private int distance = 100;

    public Horse race(HorseStable horseStable) throws InterruptedException {
        Horse winner = null;
        while (true) {
            for (int i = 0; i < horseStable.stable.length; i++) {
                horseStable.stable[i].setCurrentDistance(horseStable.stable[i].getCurrentDistance() + horseStable.stable[i].getSpeed());
                horseStable.stable[i].setSpeed((int) (horseStable.stable[i].getMinSpeed() + Math.random() * horseStable.stable[i].getMaxSpeed()));
                System.out.printf("%7s  - %2d м \n", horseStable.stable[i].getHorseName(),horseStable.stable[i].getCurrentDistance());
                if (horseStable.stable[i].getCurrentDistance() >= distance) {
                    winner = horseStable.stable[i];
                }
            }
            System.out.println("---------------");
            Thread.sleep(1000);
            return winner;
        }
    }
}