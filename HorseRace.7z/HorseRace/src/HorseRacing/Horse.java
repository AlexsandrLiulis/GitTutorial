package HorseRacing;

public class Horse {
    private String horseName;
    private int minSpeed = 1;
    private int maxSpeed = 10;
    private int speed;
    private int currentDistance;

    public Horse(String horseName) {
        this.horseName = horseName;
        speed = (int) (minSpeed + Math.random() * maxSpeed);
        currentDistance = 0;
    }

    public int getMinSpeed() {
        return minSpeed;
    }

    public int getMaxSpeed() {
        return maxSpeed;
    }

    public String getHorseName() {
        return horseName;
    }

    public int getSpeed() {
        return speed;
    }

    public int getCurrentDistance() {
        return currentDistance;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public void setCurrentDistance(int currentDistance) {
        this.currentDistance = currentDistance;
    }
}